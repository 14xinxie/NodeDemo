/*
 * @Author: mikey.zhaopeng 
 * @Date: 2018-04-26 17:59:57 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2018-04-27 10:40:54
 */

 'use strict';

 const dyNetworkSegment =  require('./dyNetwork');

 module.exports = {
     dyNetworkSegment
 };